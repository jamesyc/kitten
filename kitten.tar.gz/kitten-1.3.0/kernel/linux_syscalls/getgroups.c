#include <lwk/types.h>

long
sys_getgroups(int n, gid_t gids[])
{
	return 0;
}
