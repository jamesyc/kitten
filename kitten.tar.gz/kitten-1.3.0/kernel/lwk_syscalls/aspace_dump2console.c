#include <lwk/aspace.h>

int
sys_aspace_dump2console(
	id_t    id
)
{
	return aspace_dump2console(id);
}
