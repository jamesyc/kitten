#ifndef _ASM_X86_ACPI_H
#define _ASM_X86_ACPI_H

static inline void acpi_noirq_set(void) { }

#endif
