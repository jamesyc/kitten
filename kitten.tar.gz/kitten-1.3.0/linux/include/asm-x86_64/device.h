/**
 * \file
 * Architecture specific portion of Linux device structure.
 */
#ifndef __LINUX_ASM_DEVICE_H
#define __LINUX_ASM_DEVICE_H

struct dev_archdata { };

#endif
