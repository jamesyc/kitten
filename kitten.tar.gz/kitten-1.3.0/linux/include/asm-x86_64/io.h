#include <arch/io.h>
extern void __iomem *ioremap_wc(resource_size_t offset, unsigned long size);

