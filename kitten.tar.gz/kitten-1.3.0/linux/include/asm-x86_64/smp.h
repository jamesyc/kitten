#include <arch/smp.h>
