#define ETH_P_8021Q     0x8100          /* 802.1Q VLAN Extended Header  */

