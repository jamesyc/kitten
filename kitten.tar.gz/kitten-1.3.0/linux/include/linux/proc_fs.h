#ifndef _LINUX_PROC_FS_H
#define  _LINUX_PROC_FS_H

#define remove_proc_entry(name, parent) do {} while (0)

#endif
