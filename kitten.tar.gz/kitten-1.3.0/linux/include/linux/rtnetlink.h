/* Empty file */
extern void rtnl_lock(void);
extern void rtnl_unlock(void);

