#ifndef __LINUX_TYPES_H
#define __LINUX_TYPES_H

#include <lwk/types.h>

typedef paddr_t resource_size_t;
typedef unsigned __bitwise__ fmode_t;

#endif
