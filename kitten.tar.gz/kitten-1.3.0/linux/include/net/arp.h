#ifndef _NET_ARP_H
#define _NET_ARP_H

#include <net/neighbour.h>

extern struct neigh_table arp_tbl;

#endif
