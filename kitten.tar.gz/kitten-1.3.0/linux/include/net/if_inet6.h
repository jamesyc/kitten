#ifndef _NET_IF_INET6_H
#define _NET_IF_INET6_H

#include <linux/in6.h>

static inline void ipv6_ib_mc_map(const struct in6_addr *addr,
                  const unsigned char *broadcast, char *buf)
{
        LINUX_DBG(TRUE,"\n");

}
#endif
