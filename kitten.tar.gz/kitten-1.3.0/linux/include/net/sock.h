#ifndef _NET_SOCK_H
#define _NET_SOCK_H

#define PROT_SOCK 1024

#endif
