/** \file
 * Do nothing module.
 *
 * This file only exists to appease the kbuild gods.
 */
