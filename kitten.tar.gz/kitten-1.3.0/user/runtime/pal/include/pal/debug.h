#ifndef PAL_DEBUG_H
#define PAL_DEBUG_H

#include <pct/debug.h>

#endif
