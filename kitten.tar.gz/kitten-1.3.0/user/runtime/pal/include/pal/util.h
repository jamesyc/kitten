#ifndef PAL_UTIL_H
#define PAL_UTIL_H
#include <pct/util.h>
#endif
