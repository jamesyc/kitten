
#define sizeofVec( vec ) ( sizeof( vec.at(0) ) * vec.size() )
